package example.com.remotecontrol.mcontrol.setting.entity;

public class StartTestUIEntity {
    private String result;

    public String getResult() {
        return this.result;
    }

    public void setResult(String paramString) {
        this.result = paramString;
    }
}

