package example.com.remotecontrol.multiscreen;

import android.os.Environment;

public class Constant {

    /** 本软件根目录 */
    public static final int  WIDTH_1080P = 1920;
    public static final int  HEIGHT_1080P = 1080;

}