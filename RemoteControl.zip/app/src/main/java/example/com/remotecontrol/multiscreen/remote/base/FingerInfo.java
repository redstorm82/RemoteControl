package example.com.remotecontrol.multiscreen.remote.base;

public class FingerInfo {
    private int x;
    private int y;
    private int press;

    public void setX(int x) {
        this.x = x;
    }

    public int getX() {
        return this.x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getY() {
        return this.y;
    }

    public void setPress(int press) {
        this.press = press;
    }

    public int getPress() {
        return this.press;
    }
}
