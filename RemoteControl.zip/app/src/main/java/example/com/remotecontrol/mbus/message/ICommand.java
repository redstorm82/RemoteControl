package example.com.remotecontrol.mbus.message;

public abstract interface ICommand {
}
