package example.com.remotecontrol.mcontrol.setting.entity;

public class StopTestUIEntity {
    private String result;

    public String getResult() {
        return this.result;
    }

    public void setResult(String paramString) {
        this.result = paramString;
    }
}
