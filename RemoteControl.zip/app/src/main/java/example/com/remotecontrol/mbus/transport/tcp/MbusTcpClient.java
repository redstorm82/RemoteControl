package example.com.remotecontrol.mbus.transport.tcp;

import example.com.remotecontrol.mbus.message.AbstractMbusCommand;
import example.com.remotecontrol.mbus.transport.IMbus;

public class MbusTcpClient
        implements IMbus {
    public void connect()
            throws Exception {
    }

    public void send(AbstractMbusCommand paramAbstractMbusCommand)
            throws Exception {
    }

    public void send(AbstractMbusCommand paramAbstractMbusCommand, String paramString)
            throws Exception {
    }

    public void send(AbstractMbusCommand paramAbstractMbusCommand, String paramString, int paramInt)
            throws Exception {
    }

    public byte[] receive()
            throws Exception {
        return null;
    }

    public void disconnect()
            throws Exception {
    }
}
